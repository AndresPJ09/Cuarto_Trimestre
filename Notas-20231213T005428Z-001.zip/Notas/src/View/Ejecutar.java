/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.Materia;

/**
 *
 * @author Ambiente 209-2
 */
public class Ejecutar {
      public static void main(String[] args) {
        Materia materia = new Materia();

        System.out.println("Capturar notas de trabajos:");
        materia.capturarTrabajos();

        System.out.println("Capturar notas de parciales:");
        materia.capturarParciales();

        double notaDefinitiva = materia.calcularNotaDefinitiva();
        System.out.println("La nota definitiva es: " + notaDefinitiva);
    }
}
