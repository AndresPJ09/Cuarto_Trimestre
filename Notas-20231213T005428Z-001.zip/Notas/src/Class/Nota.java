/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import java.util.Scanner;

/**
 *
 * @author Ambiente 209-2
 */
public class Nota {
    
    private static Scanner sc = new Scanner(System.in);

    public static double ingresarNota(String tipoNota) {
        double nota;
        
        do {
            System.out.print("Ingrese la nota de " + tipoNota + ": ");
            nota = sc.nextDouble();
            
        } while (nota < 0.0 || nota > 5.0);
        return nota;
    }
}




