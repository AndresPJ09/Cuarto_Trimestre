/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Interface.Notas;

/**
 *
 * @author Ambiente 209-2
 */

public class Materia implements Notas {
    private double notaTrabajos;
    private double notaParciales;

    @Override
    public void capturarTrabajos() {
        CapturaNumero captura = new CapturaNumero();
        int n = (int) captura.capturarNumero();
        for (int i = 1; i <= n; i++) {
            double nota = Nota.ingresarNota("trabajo " + i);
            notaTrabajos += nota;
        }
    }

    @Override
    public void capturarParciales() {
        for (int i = 1; i <= 3; i++) {
            double nota = Nota.ingresarNota("parcial " + i);
            notaParciales += nota;
        }
    }

    @Override
    public double calcularNotaDefinitiva() {
        double notaFinal = (notaTrabajos * 0.4) + (notaParciales * 0.6);
        return notaFinal;
    }
}